<?php
include "koneksi.php";


$user = $conn->query("SELECT * FROM users LIMIT 1")->fetch_assoc();

$education = $conn->query("SELECT * FROM education");

$skills = $conn->query("SELECT * FROM skills");

$experiences = $conn->query("SELECT * FROM experiences");
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <title>Portofolio - <?php echo $user['name']; ?></title>

  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Charmonman:wght@400;700&family=Henny+Penny&display=swap" rel="stylesheet">
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link rel="stylesheet" href="style.css">
</head>

<body>


<nav class="navbar navbar-expand-lg navbar-light custom-navbar fixed-top shadow-sm">
  <div class="container">
    <a class="navbar-brand fw-bold" href="#home">
      <?php echo $user['name']; ?>'s Portofolio
    </a>

    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item"><a class="nav-link" href="#home">Home</a></li>
        <li class="nav-item"><a class="nav-link" href="#about">About Me</a></li>
        <li class="nav-item"><a class="nav-link" href="#experiences">Experience</a></li>
        <li class="nav-item"><a class="nav-link" href="#contact">Contact</a></li>
      </ul>
    </div>
  </div>
</nav>


<section id="home" class="hero-section d-flex align-items-center">
  <div class="container">
    <div class="row align-items-center">

      <div class="col-md-6">
        <h1 class="hero-title">Hi, I'm <?php echo $user['name']; ?></h1>
        <p class="hero-subtitle"><?php echo $user['role']; ?></p>
        <p class="hero-desc"><?php echo $user['hero_description']; ?></p>
        <a href="#about" class="btn btn-light custom-btn mt-3">More about me!</a>
      </div>

      <div class="col-md-6 text-center">
        <img src="images/Profile Image.png" class="img-fluid hero-img">
      </div>

    </div>
  </div>
</section>


<section id="about" class="py-5">
  <div class="container">
    <h2 class="section-title text-center mb-5">About Me</h2>

    <div class="row">

      <div class="col-lg-6 mb-4">
        <div class="about-card">
          <h4>Who Am I?</h4>
          <p><?php echo $user['about']; ?></p>

          <h5 class="mt-4">Education</h5>
          <ul>
            <?php while($edu = $education->fetch_assoc()) { ?>
              <li><?php echo $edu['text']; ?></li>
            <?php } ?>
          </ul>
        </div>
      </div>

      <div class="col-lg-6">
        <div class="about-card">
          <h4>My Skills</h4>

          <?php while($skill = $skills->fetch_assoc()) { ?>
            <div class="mb-4">

              <div class="d-flex justify-content-between">
                <span class="fw-semibold"><?php echo $skill['name']; ?></span>
                <span class="skill-percent"><?php echo $skill['level']; ?>%</span>
              </div>

              <div class="skill-bar-container mt-2">
                <div class="skill-bar"
                    style="width: <?php echo $skill['level']; ?>%">
                </div>
              </div>

            </div>
          <?php } ?>

        </div>
      </div>

    </div>
  </div>
</section>


<section id="experiences" class="py-5 experiences-section">
  <div class="container">
    <h2 class="section-title text-center mb-5">Experiences</h2>

    <div class="row g-4">

      <?php while($exp = $experiences->fetch_assoc()) { ?>
        <div class="col-md-4">
          <div class="card experience-card h-100 shadow-sm">
            <img src="<?php echo $exp['image']; ?>" class="card-img-top">
            <div class="card-body">
              <h5><?php echo $exp['title']; ?></h5>
              <p><?php echo $exp['description']; ?></p>
            </div>
          </div>
        </div>
      <?php } ?>

    </div>
  </div>
</section>


<section id="contact" class="contact-section py-5">
  <div class="container text-center">
    <h2 class="section-title mb-4">Let's Work Together!</h2>
    <p class="mb-4">Feel free to reach out via social media or email.</p>

  
    <div class="social-icons mb-4">
      <a href="#" class="social-icon">Instagram</a>
      <a href="#" class="social-icon">Facebook</a>
      <a href="#" class="social-icon">TikTok</a>
      <a href="#" class="social-icon">Twitter</a>
    </div>

  
    <p class="contact-info">
  <i class="bi bi-envelope-fill me-2"></i>
  <?php echo $user['email']; ?>
</p>

    <a href="#" class="btn btn-light custom-btn">Contact Me!</a>
  </div>
</section>

<footer class="text-center py-3 footer">
  <small>© 2026 <?php echo $user['name']; ?>. All Rights Reserved.</small>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>